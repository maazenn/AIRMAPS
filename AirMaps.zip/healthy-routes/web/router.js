// AirMaps - routing engine (works in the browser and in Node for testing)
//
// Time is a single index k = day * (hours per day) + hour, matching the order in the data file.

const WALK_SPEED_MS = 1.3; // average walking speed, metres per second

// Car comparison (rough, stated in the app): a car's route is ~25% longer than the walking route
// (one-way streets, no footpath short cuts), a typical car uses 9 L per 100 km in city traffic,
// and burning 1 L of petrol releases 2.31 kg of CO2.
const CAR = { detour: 1.25, litresPer100km: 9, co2KgPerLitre: 2.31, tripsPerYear: 2 * 250 };

// Share of a street in the sun (0..1) at time k
function sunAt(e, k) { return (e.s.charCodeAt(k) - 97) / 20; }

// Air pollution score 0..100 on a street at time k: the street's traffic score, raised or
// lowered by the city's measured air quality that hour (Copernicus US AQI; 150 = unhealthy)
function polAt(e, k, meta) {
  if (!meta.aq) return e.pol;
  const bg = Math.min(1, Math.max(0, meta.aq.aqi[k] / 150));
  return 0.65 * e.pol + 35 * bg;
}

// Turn older data files (one day, numeric arrays) into the current format
function normalizeData(data) {
  const m = data.meta;
  if (!m.days) m.days = [m.date || "2025-07-15"];
  if (!m.tz) m.tz = "Asia/Dubai";
  if (!m.units) m.units = "metric";
  for (const e of data.edges) {
    if (e.s === undefined && e.sun) {
      e.s = e.sun.map(v => String.fromCharCode(97 + Math.round(v / 5))).join("");
      delete e.sun;
    }
  }
  return data;
}

class MinHeap {
  constructor() { this.items = []; }
  get size() { return this.items.length; }
  push(node, cost) {
    const a = this.items; a.push([cost, node]);
    let i = a.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (a[p][0] <= a[i][0]) break;
      [a[p], a[i]] = [a[i], a[p]]; i = p;
    }
  }
  pop() {
    const a = this.items, top = a[0], last = a.pop();
    if (a.length) {
      a[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = l + 1;
        let m = i;
        if (l < a.length && a[l][0] < a[m][0]) m = l;
        if (r < a.length && a[r][0] < a[m][0]) m = r;
        if (m === i) break;
        [a[m], a[i]] = [a[i], a[m]]; i = m;
      }
    }
    return top;
  }
}

// adjacency list: for every junction, the list of street segments touching it
function buildGraph(data) {
  const adj = data.nodes.map(() => []);
  data.edges.forEach((e, i) => { adj[e.u].push(i); adj[e.v].push(i); });
  return adj;
}

// Estimated "feels-like" temperature on a street at time k (°C)
function feelsLike(edge, k, meta) {
  const elev = Math.max(0, meta.sunElevation[k]);
  return meta.feelsLike[k] + sunAt(edge, k) * meta.sunBoostC * Math.sin(elev * Math.PI / 180);
}

// 0..1 heat score: 30°C feels-like or below = 0, 50°C or above = 1
function heatScore(edge, k, meta) {
  return Math.min(1, Math.max(0, (feelsLike(edge, k, meta) - 30) / 20));
}

// Cost of walking one street segment. weights = {sun, heat, pol}; all zero = shortest path.
// sun > 0 avoids sun (penalises sunny streets); sun < 0 seeks sun (penalises shaded streets
// while the sun is up). Costs never go below the plain distance, so Dijkstra stays correct.
function edgeCost(edge, k, meta, w) {
  const sun = sunAt(edge, k);
  let sunPenalty = 0;
  if (w.sun > 0) sunPenalty = w.sun * sun;
  else if (w.sun < 0 && meta.sunElevation[k] > 2) sunPenalty = -w.sun * (1 - sun);
  const penalty = sunPenalty + w.heat * heatScore(edge, k, meta) + w.pol * (polAt(edge, k, meta) / 100);
  return edge.len * (1 + penalty);
}

// Dijkstra's algorithm. Returns { edges: [edge ids in order], nodes: [node ids] } or null
function findRoute(data, adj, from, to, h, w) {
  const n = data.nodes.length;
  const dist = new Float64Array(n).fill(Infinity);
  const viaEdge = new Int32Array(n).fill(-1);
  const heap = new MinHeap();
  dist[from] = 0; heap.push(from, 0);
  while (heap.size) {
    const [d, u] = heap.pop();
    if (u === to) break;
    if (d > dist[u]) continue;
    for (const ei of adj[u]) {
      const e = data.edges[ei];
      const v = e.u === u ? e.v : e.u;
      const nd = d + edgeCost(e, h, data.meta, w);
      if (nd < dist[v]) { dist[v] = nd; viaEdge[v] = ei; heap.push(v, nd); }
    }
  }
  if (dist[to] === Infinity) return null;
  const edges = [], nodes = [to];
  for (let cur = to; cur !== from;) {
    const ei = viaEdge[cur], e = data.edges[ei];
    edges.push(ei);
    cur = e.u === cur ? e.v : e.u;
    nodes.push(cur);
  }
  return { edges: edges.reverse(), nodes: nodes.reverse() };
}

// Health numbers for a route
function routeStats(data, route, h) {
  let len = 0, sunM = 0, polSum = 0, feelSum = 0;
  for (const ei of route.edges) {
    const e = data.edges[ei];
    len += e.len;
    sunM += e.len * sunAt(e, h);
    polSum += e.len * polAt(e, h, data.meta) / 100;
    feelSum += e.len * feelsLike(e, h, data.meta);
  }
  const safe = len || 1;
  return {
    lengthM: len,
    minutes: len / WALK_SPEED_MS / 60,
    sunMetres: sunM,
    sunPct: 100 * sunM / safe,
    sunMinutes: sunM / WALK_SPEED_MS / 60,
    pollution: 100 * polSum / safe,                       // average pollution index 0-100
    pollutionDose: polSum / WALK_SPEED_MS / 60,          // "polluted minutes" (index x time)
    avgFeelsLike: feelSum / safe,
  };
}

// A street's geometry pointing away from the junction we arrive from.
// Returns { g: [[lat, lon], ...], forward: true if this is the stored drawing direction }
function orientedGeom(data, e, fromNode) {
  const [la, lo] = data.nodes[fromNode], g = e.g, last = g[g.length - 1];
  const d0 = (g[0][0] - la) ** 2 + (g[0][1] - lo) ** 2;
  const d1 = (last[0] - la) ** 2 + (last[1] - lo) ** 2;
  return d0 <= d1 ? { g, forward: true } : { g: g.slice().reverse(), forward: false };
}

// Route geometry as [lat, lon] points in walking order
function routeLatLngs(data, route) {
  const pts = [];
  route.edges.forEach((ei, k) => {
    const { g } = orientedGeom(data, data.edges[ei], route.nodes[k]);
    pts.push(...(pts.length ? g.slice(1) : g));
  });
  return pts;
}

// ---------------------------------------------------------------------------
// Turn-by-turn directions
// ---------------------------------------------------------------------------
const HW_LABEL = {
  footway: "the footpath", pedestrian: "the pedestrian street", path: "the path", steps: "the steps",
  cycleway: "the cycle path", corridor: "the covered walkway", service: "the service road",
  track: "the track", living_street: "the street", residential: "the street",
};
const COMPASS = ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"];

function streetLabel(e) { return e.nm || HW_LABEL[e.hw] || "the road"; }

function bearingDeg(a, b) {
  const toR = Math.PI / 180, la1 = a[0] * toR, la2 = b[0] * toR, dl = (b[1] - a[1]) * toR;
  const y = Math.sin(dl) * Math.cos(la2);
  const x = Math.cos(la1) * Math.sin(la2) - Math.sin(la1) * Math.cos(la2) * Math.cos(dl);
  return (Math.atan2(y, x) / toR + 360) % 360;
}

// bearing at the start / end of a line, skipping tiny wiggles
function lineBearing(g, atEnd) {
  if (g.length < 2) return 0;
  return atEnd ? bearingDeg(g[Math.max(0, g.length - 3)], g[g.length - 1])
               : bearingDeg(g[0], g[Math.min(g.length - 1, 2)]);
}

let UNITS = "metric";
function setUnits(u) { UNITS = u === "us" ? "us" : "metric"; }

function fmtDist(m) {
  if (UNITS === "us") {
    const ft = m * 3.28084;
    if (ft >= 1000) return (m / 1609.34).toFixed(1) + " mi";
    return Math.max(30, Math.round(ft / 10) * 10) + " ft";
  }
  if (m >= 1000) return (m / 1000).toFixed(1) + " km";
  return Math.max(10, Math.round(m / 10) * 10) + " m";
}

function turnPhrase(turn) {
  const a = Math.abs(turn), dir = turn > 0 ? "right" : "left";
  if (a < 25) return "Continue";
  if (a < 60) return "Bear " + dir;
  if (a < 150) return "Turn " + dir;
  return "Turn around";
}

// prefer: "shade" (tips say which side is shadier) or "sun" (which side is sunnier)
function routeDirections(data, route, h, prefer = "shade") {
  const steps = [];
  let prevOut = null;
  route.edges.forEach((ei, k) => {
    const e = data.edges[ei];
    const { g, forward } = orientedGeom(data, e, route.nodes[k]);
    const bin = lineBearing(g, false), bout = lineBearing(g, true);
    const label = streetLabel(e);
    const code = e.sd ? +e.sd[h] : 0;
    const side = code === 0 ? null : ((code === 1) === forward ? "left" : "right");
    const sunM = e.len * sunAt(e, h);
    const last = steps[steps.length - 1];
    const turn = prevOut === null ? 0 : ((bin - prevOut + 540) % 360) - 180;
    if (last && label === last.label && Math.abs(turn) < 35) {
      last.dist += e.len; last.sunM += sunM;
    } else {
      steps.push({ label, named: !!e.nm, turn, first: prevOut === null, bearing: bin, dist: e.len, sunM, left: 0, right: 0, at: g[0] });
    }
    const cur = steps[steps.length - 1];
    if (side) cur[side] += e.len;
    prevOut = bout;
  });

  // fold very short unnamed links (crossings, kinks) into the step before them
  for (let i = steps.length - 1; i > 0; i--) {
    const s = steps[i];
    if (s.dist < 15 && !s.named) {
      const p = steps[i - 1];
      p.dist += s.dist; p.sunM += s.sunM; p.left += s.left; p.right += s.right;
      steps.splice(i, 1);
    }
  }

  const out = steps.map((s, i) => {
    let text;
    if (i === 0) text = `Head ${COMPASS[Math.round(s.bearing / 45) % 8]} on ${s.label}`;
    else {
      const phrase = turnPhrase(s.turn);
      text = phrase === "Continue" ? `Continue onto ${s.label}` : `${phrase} onto ${s.label}`;
    }
    const sunPct = s.dist ? 100 * s.sunM / s.dist : 0;
    const shade = sunPct < 25 ? "mostly shaded" : sunPct > 75 ? "in full sun" : "partly shaded";
    let tip = "";
    const sideM = Math.max(s.left, s.right);
    if (sideM > 0.5 * s.dist && sunPct > 10) {
      const shady = s.left >= s.right ? "left" : "right";
      tip = prefer === "sun" ? `walk on the ${shady === "left" ? "right" : "left"} side for sun`
                             : `walk on the ${shady} side for shade`;
    }
    const turnType = i === 0 ? "start" : (Math.abs(s.turn) < 25 ? "straight" : s.turn > 0 ? "right" : "left");
    return { text, dist: s.dist, distText: fmtDist(s.dist), minutes: s.dist / WALK_SPEED_MS / 60,
             sunPct, shade, tip, turnType, sharp: Math.abs(s.turn) >= 60, at: s.at };
  });
  const end = data.nodes[route.nodes[route.nodes.length - 1]];
  out.push({ text: "Arrive at your destination", dist: 0, distText: "", minutes: 0, sunPct: 0, shade: "", tip: "", turnType: "arrive", at: end });
  return out;
}

// Fuel and CO2 a car would use for the same trip
function fuelSaved(walkMetres) {
  const km = walkMetres * CAR.detour / 1000;
  const litres = km * CAR.litresPer100km / 100;
  const co2Kg = litres * CAR.co2KgPerLitre;
  return { litres, co2Kg, gallons: litres * 0.264172, co2Lb: co2Kg * 2.20462,
           yearLitres: litres * CAR.tripsPerYear, yearCo2Kg: co2Kg * CAR.tripsPerYear,
           yearGallons: litres * 0.264172 * CAR.tripsPerYear, yearCo2Lb: co2Kg * 2.20462 * CAR.tripsPerYear };
}

function nearestNode(data, lat, lon) {
  let best = -1, bd = Infinity;
  const k = Math.cos(lat * Math.PI / 180);
  data.nodes.forEach(([y, x], i) => {
    const d = (y - lat) ** 2 + ((x - lon) * k) ** 2;
    if (d < bd) { bd = d; best = i; }
  });
  return best;
}

if (typeof module !== "undefined") {
  module.exports = { buildGraph, findRoute, routeStats, routeLatLngs, routeDirections, nearestNode,
                     feelsLike, heatScore, edgeCost, bearingDeg, streetLabel, sunAt, polAt, normalizeData,
                     fuelSaved, CAR, setUnits, fmtDist, WALK_SPEED_MS };
}
