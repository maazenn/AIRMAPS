@echo off
title AirMaps - keep this window open while you use the map
cd /d "%~dp0web"
echo.
echo   AirMaps is running.
echo   Your browser will open at http://127.0.0.1:8000
echo.
echo   Keep this window open while you use the map.
echo   Close it when you're finished.
echo.
start "" http://127.0.0.1:8000
python -m http.server 8000 --bind 127.0.0.1
if errorlevel 1 (
  echo.
  echo   Something went wrong. If it says the port is already in use,
  echo   AirMaps is probably already running in another window.
  pause
)
