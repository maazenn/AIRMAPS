# AirMaps

A walking map that finds the **healthiest route**, not just the shortest one: it avoids
direct sun, heat and traffic fumes, or seeks the sun on cold days. Ready-made areas in Dubai,
New York, London, Singapore, Hong Kong, Lahore and New Delhi, and it works for any city in OpenStreetMap.

**SDG links:** 3 (health, 3.9 air pollution), 11 (sustainable cities, 11.6 air quality),
13 (climate: heat adaptation and fewer car trips), 8 (decent work: outdoor workers and delivery riders).

## Features

- **Healthiest or fastest:** switch between the two routes; the other one stays on the map, dashed
- **Real, recent data:** the most recent 7 days with verified weather (ERA5) and hourly air quality (Copernicus),
  any hour from 5am to 9pm. Run the script again to bring it up to date
- **Sunrise and sunset light**, **night mode** with lit windows and street lamps
- **Trip time:** walk time, distance, leave and arrive times, minutes in the sun
- **Fuel and CO₂ saved** by walking instead of driving, per trip and per year
- **Turn-by-turn directions** with street names, shade per step and which side of the street to walk on
- **Type a start and destination** (streets, shops, stations, named buildings, or coordinates like `25.27, 55.31`),
  tap the map, drag the pins, swap them, or use your location
- **Sun slider from "avoid" to "seek"** for people who want sunny routes in winter
- **3D buildings** with shadows that move with the time of day
- **Several cities:** Deira, Al Sufouh and Downtown Dubai, Midtown Manhattan, Central London,
  Downtown Singapore, Central Hong Kong, Mall Road (Lahore) and Connaught Place (New Delhi) ready to build
- **Collapsible panel**, light and dark mode, works on phones
- Clean map drawn from our own data; no map service or API key needed in the app

## How to run it

You need Python 3.10+ installed. In cmd, inside the `healthy-routes` folder:

```bash
pip install -r requirements.txt           # once (and again after this update: adds tzdata)
python build_data.py                      # builds Deira
python build_data.py --city al-sufouh     # builds another area
python build_data.py --city new-york
python build_data.py --city all           # every ready-made area
python build_data.py --list               # shows the ready-made areas
python build_data.py --recent-days 1      # only the single most recent verified day
python build_data.py --monthly            # the 15th of every month of last year (to show the seasons)
cd web
python -m http.server 8000
```

Then open **http://localhost:8000**. Every area you've built appears in the dropdown under the AirMaps title.

Each area takes a few minutes. Weather comes from the ERA5 record, which runs about 5 days behind today,
so the newest day in the app is usually 5-6 days ago.

Your own area: `python build_data.py --bbox WEST SOUTH EAST NORTH --name "My area" --tz Europe/London`

Real air-quality station readings (recommended): get a free token at
https://aqicn.org/data-platform/token/ and run `set WAQI_TOKEN=your_token` (Windows) before `python build_data.py`.

## How it works

| Step | What happens | Data |
|---|---|---|
| Streets | Every walkable street and footpath, with English names where mapped | OpenStreetMap via OSMnx |
| Buildings, trees, water, parks, places | Outlines, heights or floors where mapped (otherwise an estimate), named places for search | OpenStreetMap |
| Sun & shade | Sun position for each hour of each modelled day; every building's shadow is cast and the share of each street in the sun is measured, on both pavements | NOAA solar formula + shadow geometry |
| Heat | Hourly air and feels-like temperature for each modelled day, plus an estimated extra up to 8°C in direct sun | Open-Meteo historical weather, ERA5 reanalysis (free) |
| Pollution | Hourly city-wide US AQI, PM2.5 and NO₂, plus a street-level traffic score from road type and closeness to major roads; optional monitoring stations | Copernicus CAMS via Open-Meteo, OSM, optional WAQI / Google |
| Routing | Dijkstra's algorithm twice: once on distance, once on distance x (1 + sun + heat + pollution penalties) | in the browser |
| Car comparison | Driving distance 25% longer than walking, 9 L/100 km, 2.31 kg CO₂ per litre, 500 trips a year | stated estimates |

## Honest limitations

- **Building heights:** many buildings have no height in OpenStreetMap, so an estimate is used (Manhattan is well mapped, Dubai less so).
- **Pollution is approximate at street level.** Stations are kilometres apart; the traffic score is a proxy.
- **Feels-like in sun** is a simple estimate, not a full thermal-comfort model.
- **Whole-city maps** aren't practical in a browser: each neighbourhood is a few MB, so all of Dubai would be hundreds.
- Shade is modelled at each full hour, not every minute.
- City air quality is a ~10-45 km model grid, so it changes hour by hour but not street by street; the traffic score adds the street detail.
