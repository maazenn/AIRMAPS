"""
AirMaps - data builder
======================

Downloads streets, buildings, trees, water, parks and named places for one area
from OpenStreetMap, finds the most recent days with verified weather and
air-quality records, works out how much of each street is in the sun for every
hour from 5am to 9pm on those days, and writes everything to web/data/<area>.json
for the app (plus web/data/areas.json, the list of areas you have built).

Weather: Open-Meteo historical weather (ERA5 reanalysis, about 5 days behind today).
Air quality: Open-Meteo air quality (Copernicus CAMS), hourly PM2.5, NO2 and US AQI.
Run it again any time to bring the data up to date.

Usage (from the healthy-routes folder):

    pip install -r requirements.txt
    python build_data.py                        # Deira, Dubai (default)
    python build_data.py --city al-sufouh       # another ready-made area
    python build_data.py --city all             # every ready-made area (takes a while)
    python build_data.py --list                 # show the ready-made areas
    python build_data.py --recent-days 1        # only the single most recent verified day
    python build_data.py --monthly              # the 15th of every month of last year instead

    # any other area: west south east north, a name and its time zone
    python build_data.py --bbox 55.30 25.255 55.335 25.285 --name "My area" --tz Asia/Dubai

Optional (set in your terminal before running):

    WAQI_TOKEN=xxxx      free token from https://aqicn.org/data-platform/token/
                         -> real air-quality station readings
    GOOGLE_AQ_KEY=xxxx   Google Air Quality API key (billing enabled)
                         -> fills gaps between stations (uses ~60 calls per run)

Without them, air quality = the city's hourly Copernicus readings plus a street-level
traffic score (how busy the road is and how close you are to a major road).
"""

import argparse
import gc
import json
import math
import os
import shutil
import sys
import time
from datetime import datetime, timedelta, timezone

import numpy as np
import requests
import shapely
from shapely.geometry import LineString, MultiPolygon, Polygon

# ---------------------------------------------------------------------------
# Ready-made areas
# ---------------------------------------------------------------------------
CITIES = {
    "deira": {
        "name": "Deira, Dubai", "bbox": (55.300, 25.255, 55.335, 25.285),
        "tz": "Asia/Dubai", "utc_offset": 4, "units": "metric", "default_height": 12,
        "about": "Old Dubai: souqs, Naif, Al Rigga and the creek",
    },
    "al-sufouh": {
        "name": "Al Sufouh, Dubai", "bbox": (55.152, 25.095, 55.192, 25.128),
        "tz": "Asia/Dubai", "utc_offset": 4, "units": "metric", "default_height": 9,
        "about": "Al Sufouh 1 and 2, Knowledge Park and the beach road",
    },
    "downtown-dubai": {
        "name": "Downtown Dubai", "bbox": (55.265, 25.185, 55.290, 25.205),
        "tz": "Asia/Dubai", "utc_offset": 4, "units": "metric", "default_height": 30,
        "about": "Burj Khalifa, Dubai Mall and Business Bay edge",
    },
    "new-york": {
        "name": "Midtown Manhattan, New York", "bbox": (-73.992, 40.750, -73.972, 40.764),
        "tz": "America/New_York", "utc_offset": None, "units": "us", "default_height": 25,
        "about": "Times Square, Bryant Park and Grand Central",
    },
    "london": {
        "name": "Central London", "bbox": (-0.140, 51.505, -0.115, 51.520),
        "tz": "Europe/London", "utc_offset": None, "units": "metric", "default_height": 18,
        "about": "Trafalgar Square, Covent Garden and Soho",
    },
    "singapore": {
        "name": "Downtown Singapore", "bbox": (103.840, 1.276, 103.856, 1.290),
        "tz": "Asia/Singapore", "utc_offset": 8, "units": "metric", "default_height": 20,
        "about": "Raffles Place, Chinatown and Tanjong Pagar",
    },
    "hong-kong": {
        "name": "Central, Hong Kong", "bbox": (114.150, 22.274, 114.170, 22.289),
        "tz": "Asia/Hong_Kong", "utc_offset": 8, "units": "metric", "default_height": 40,
        "about": "IFC, Bank of China Tower, Lan Kwai Fong and Admiralty",
    },
    "lahore": {
        "name": "Mall Road, Lahore", "bbox": (74.300, 31.555, 74.325, 31.575),
        "tz": "Asia/Karachi", "utc_offset": 5, "units": "metric", "default_height": 10,
        "about": "Mall Road, Anarkali Bazaar and the Lahore Museum",
    },
    "new-delhi": {
        "name": "Connaught Place, New Delhi", "bbox": (77.208, 28.623, 77.228, 28.640),
        "tz": "Asia/Kolkata", "utc_offset": 5.5, "units": "metric", "default_height": 12,
        "about": "Connaught Place, Janpath and Barakhamba Road",
    },
}
DEFAULT_CITY = "deira"

HOURS = list(range(5, 22))         # 5am .. 9pm local time (includes sunrise and sunset)
DEFAULT_RECENT_DAYS = 7            # most recent verified days to model
SAMPLE_STEP_M = 5                  # check shade every 5 m along a street
METRES_PER_LEVEL = 3.2
TREE_HEIGHT_M = 6
TREE_CANOPY_RADIUS_M = 3
SUN_FEELS_LIKE_BOOST_C = 8         # rough extra "feels-like" heat in full sun
MAX_PLACES = 5000                  # named places kept for search

# How busy / polluting each kind of road is (0 = clean footpath, 1 = motorway)
TRAFFIC_FACTOR = {
    "motorway": 1.0, "motorway_link": 0.9, "trunk": 1.0, "trunk_link": 0.9,
    "primary": 0.8, "primary_link": 0.7, "secondary": 0.6, "secondary_link": 0.55,
    "tertiary": 0.45, "tertiary_link": 0.4, "unclassified": 0.3, "residential": 0.25,
    "living_street": 0.15, "service": 0.2, "footway": 0.08, "pedestrian": 0.05,
    "path": 0.05, "steps": 0.08, "cycleway": 0.08, "track": 0.1, "corridor": 0.05,
}
# Half the road width: how far the pavement is from the centre line
PAVEMENT_OFFSET_M = {
    "trunk": 14, "primary": 11, "secondary": 9, "tertiary": 7, "unclassified": 5,
    "residential": 5, "living_street": 4, "service": 4,
}


# ---------------------------------------------------------------------------
# 1. Time and sun position (NOAA solar position algorithm)
# ---------------------------------------------------------------------------
def local_to_utc(year, month, day, hour, tz_name, utc_offset):
    """Local clock time in the area -> UTC. Uses the time-zone database (handles daylight saving)."""
    try:
        from zoneinfo import ZoneInfo
        local = datetime(year, month, day, hour, tzinfo=ZoneInfo(tz_name))
        return local.astimezone(timezone.utc)
    except Exception:
        # no time-zone database (pip install tzdata) - fall back to a fixed offset
        if utc_offset is None:  # rough daylight-saving rules for New York and London
            summer = 3 < month < 11 or (month == 3 and day >= 14) or (month == 11 and day < 7)
            utc_offset = (-4 if summer else -5) if tz_name.startswith("America/") else (1 if 3 < month < 11 else 0)
        return datetime(year, month, day, hour, tzinfo=timezone.utc) - timedelta(hours=utc_offset)


def sun_position(lat, lon, when_utc):
    """Return (elevation_deg, azimuth_deg) of the sun. Azimuth: 0 = north, 90 = east."""
    jd = when_utc.timestamp() / 86400.0 + 2440587.5
    t = (jd - 2451545.0) / 36525.0
    l0 = (280.46646 + t * (36000.76983 + 0.0003032 * t)) % 360
    m = 357.52911 + t * (35999.05029 - 0.0001537 * t)
    e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
    mr = math.radians(m)
    c = (math.sin(mr) * (1.914602 - t * (0.004817 + 0.000014 * t))
         + math.sin(2 * mr) * (0.019993 - 0.000101 * t) + math.sin(3 * mr) * 0.000289)
    true_long = l0 + c
    omega = 125.04 - 1934.136 * t
    app_long = true_long - 0.00569 - 0.00478 * math.sin(math.radians(omega))
    eps0 = 23 + (26 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))) / 60) / 60
    eps = eps0 + 0.00256 * math.cos(math.radians(omega))
    decl = math.asin(math.sin(math.radians(eps)) * math.sin(math.radians(app_long)))
    y = math.tan(math.radians(eps / 2)) ** 2
    l0r = math.radians(l0)
    eq_time = 4 * math.degrees(
        y * math.sin(2 * l0r) - 2 * e * math.sin(mr) + 4 * e * y * math.sin(mr) * math.cos(2 * l0r)
        - 0.5 * y * y * math.sin(4 * l0r) - 1.25 * e * e * math.sin(2 * mr))
    minutes = when_utc.hour * 60 + when_utc.minute + when_utc.second / 60
    true_solar = (minutes + eq_time + 4 * lon) % 1440
    hour_angle = true_solar / 4 - 180
    latr, har = math.radians(lat), math.radians(hour_angle)
    cos_zen = math.sin(latr) * math.sin(decl) + math.cos(latr) * math.cos(decl) * math.cos(har)
    zen = math.acos(max(-1.0, min(1.0, cos_zen)))
    elevation = 90 - math.degrees(zen)
    az = math.degrees(math.atan2(
        math.sin(har), math.cos(har) * math.sin(latr) - math.tan(decl) * math.cos(latr))) + 180
    return elevation, az % 360


# ---------------------------------------------------------------------------
# 2. Shadows
# ---------------------------------------------------------------------------
def parse_height(height_tag, levels_tag, default):
    """Building height in metres from OSM tags, with a fallback."""
    for raw, mult in ((height_tag, 1.0), (levels_tag, METRES_PER_LEVEL)):
        if raw is None or (isinstance(raw, float) and math.isnan(raw)):
            continue
        try:
            value = float(str(raw).lower().replace("m", "").replace(",", ".").split(";")[0].strip())
            if value > 0:
                return value * mult
        except ValueError:
            pass
    return default


def build_sample_points(edges):
    """Points every few metres along each street, on the centre line and both pavements."""
    xs, ys, edge_idx, variant = [], [], [], []
    for i, (geom, hw) in enumerate(zip(edges.geometry, edges["hw"])):
        lines = [(0, geom)]
        offset = PAVEMENT_OFFSET_M.get(hw)
        if offset:
            for v, d in ((1, offset), (2, -offset)):
                try:
                    off = geom.offset_curve(d)
                    if isinstance(off, LineString) and not off.is_empty:
                        lines.append((v, off))
                except Exception:
                    pass
        for v, line in lines:
            n = max(2, int(line.length // SAMPLE_STEP_M) + 1)
            pts = shapely.line_interpolate_point(line, np.linspace(0, line.length, n))
            c = shapely.get_coordinates(pts)
            xs.extend(c[:, 0]); ys.extend(c[:, 1])
            edge_idx.extend([i] * n); variant.extend([v] * n)
    return np.array(xs), np.array(ys), np.array(edge_idx), np.array(variant)


class ShadowCaster:
    """Casts the shadows of every building and tree for a given sun position, quickly.

    Each shadow is the convex hull of the footprint and the footprint moved away from the
    sun by height / tan(sun elevation). All of it is done with array maths, no loops."""

    def __init__(self, polygons, heights):
        coords, idx = shapely.get_coordinates(polygons, return_index=True)
        self.coords, self.idx = coords, idx
        self.heights = np.asarray(heights, dtype=float)
        self.n = len(polygons)

    def shadows(self, elev, az):
        if self.n == 0:
            return np.array([])
        length = np.minimum(self.heights / math.tan(math.radians(elev)), 400.0)
        direction = math.radians(az + 180)  # shadows point away from the sun
        dx, dy = length * math.sin(direction), length * math.cos(direction)
        moved = self.coords + np.column_stack([dx[self.idx], dy[self.idx]])
        all_c = np.vstack([self.coords, moved])
        all_i = np.concatenate([self.idx, self.idx])
        order = np.argsort(all_i, kind="stable")
        return shapely.convex_hull(shapely.multipoints(all_c[order], indices=all_i[order]))


def compute_sun_exposure(edges, buildings, trees, lat, lon, days, tz_name, utc_offset):
    """For every street, every chosen day and every hour: share of the street in the sun.

    Returns exposure [n_edges x n_times] (0..1), shady side [n_edges x n_times]
    (0 = either, 1 = left, 2 = right, relative to the drawn direction of the street),
    and per-time sun elevation and azimuth. Times are ordered day by day, hour by hour."""
    xs, ys, eidx, var = build_sample_points(edges)
    points = shapely.points(xs, ys)
    n_edges, n_times = len(edges), len(days) * len(HOURS)
    exposure = np.zeros((n_edges, n_times), dtype=np.float32)
    side = np.zeros((n_edges, n_times), dtype=np.int8)
    elevations, azimuths = [], []
    covered = edges["covered"].to_numpy()

    polys = list(buildings.geometry) + list(trees)
    heights = list(buildings["h"]) + [TREE_HEIGHT_M] * len(trees)
    caster = ShadowCaster(polys, heights)
    masks = [(var == v) for v in (0, 1, 2)]
    counts = [np.bincount(eidx[m], minlength=n_edges) for m in masks]
    started = time.time()

    for d_i, day in enumerate(days):
        sunny_hours = 0
        for h_i, hour in enumerate(HOURS):
            k = d_i * len(HOURS) + h_i
            elev, az = sun_position(lat, lon, local_to_utc(day.year, day.month, day.day, hour, tz_name, utc_offset))
            elevations.append(round(elev, 1)); azimuths.append(round(az, 1))
            if elev <= 2:
                continue  # sun is down or barely up: everything counts as shaded
            sunny_hours += 1
            tree = shapely.STRtree(caster.shadows(elev, az))
            hit = tree.query(points, predicate="intersects")[0] if caster.n else np.array([], dtype=int)
            inside = np.zeros(len(points)); inside[np.unique(hit)] = 1

            fracs = np.zeros((3, n_edges))
            for v in (0, 1, 2):
                m = masks[v]
                if not m.any():
                    continue
                hits = np.bincount(eidx[m], weights=inside[m], minlength=n_edges)
                fracs[v] = np.divide(hits, counts[v], out=np.zeros(n_edges), where=counts[v] > 0)
            best_shade = fracs.max(axis=0)  # a walker can pick the shadier side
            gap = np.abs(fracs[1] - fracs[2])
            both = (counts[1] > 0) & (counts[2] > 0)
            side[:, k] = np.where(both & (gap >= 0.25), np.where(fracs[1] >= fracs[2], 1, 2), 0)
            exp = 1 - best_shade
            exp[covered] = 0
            exposure[:, k] = exp
        day_exp = exposure[:, d_i * len(HOURS):(d_i + 1) * len(HOURS)]
        print(f"   {day:%d %b}: {sunny_hours} hours of sun, at 2pm {day_exp[:, HOURS.index(14)].mean() * 100:3.0f}% "
              f"of street length in sun   ({time.time() - started:.0f}s)")
    return exposure, side, elevations, azimuths


# ---------------------------------------------------------------------------
# 3. Air pollution
# ---------------------------------------------------------------------------
def waqi_stations(bbox, token, margin=0.15):
    w, s, e, n = bbox
    url = (f"https://api.waqi.info/v2/map/bounds?latlng={s - margin},{w - margin},"
           f"{n + margin},{e + margin}&networks=all&token={token}")
    data = requests.get(url, timeout=30).json()
    if data.get("status") != "ok":
        raise RuntimeError(f"WAQI error: {data.get('data')}")
    stations = []
    for st in data["data"]:
        try:
            stations.append({"lat": st["lat"], "lon": st["lon"], "aqi": float(st["aqi"]),
                             "name": st.get("station", {}).get("name", "")})
        except (TypeError, ValueError, KeyError):
            pass  # station with no current reading ("-")
    return stations


def google_grid(bbox, key, spacing_m=500, max_points=60):
    """Google Air Quality at a grid of points. Returns points with 'aqi' on a 0-500 US-style scale."""
    w, s, e, n = bbox
    lat_step = spacing_m / 111_000
    lon_step = spacing_m / (111_000 * math.cos(math.radians((s + n) / 2)))
    lats, lons = np.arange(s, n + 1e-9, lat_step), np.arange(w, e + 1e-9, lon_step)
    points = [(la, lo) for la in lats for lo in lons]
    if len(points) > max_points:
        print(f"   grid has {len(points)} points, limiting to {max_points} to protect your free quota")
        points = points[:: math.ceil(len(points) / max_points)]
    out = []
    url = f"https://airquality.googleapis.com/v1/currentConditions:lookup?key={key}"
    for la, lo in points:
        r = requests.post(url, json={"location": {"latitude": la, "longitude": lo}}, timeout=30)
        if r.status_code != 200:
            print(f"   Google AQ error {r.status_code}: {r.text[:120]}")
            break
        idx = r.json().get("indexes", [{}])[0]
        uaqi = idx.get("aqi")  # Universal AQI: 100 = best, 0 = worst
        if uaqi is not None:
            out.append({"lat": la, "lon": lo, "aqi": (100 - uaqi) * 2, "name": "google"})
    print(f"   used {len(points)} Google calls")
    return out


def idw(lat, lon, points, power=2):
    """Inverse-distance-weighted average of nearby readings."""
    num = den = 0.0
    for p in points:
        d = math.hypot((p["lat"] - lat) * 111, (p["lon"] - lon) * 111 * math.cos(math.radians(lat)))
        if d < 0.05:
            return p["aqi"]
        wgt = 1 / d ** power
        num += wgt * p["aqi"]; den += wgt
    return num / den if den else None


def compute_pollution(edges, readings):
    """Score 0..1 per street = background air quality + local traffic effect."""
    traffic = edges["hw"].map(lambda h: TRAFFIC_FACTOR.get(h, 0.2)).to_numpy().copy()

    # being next to a big road counts even if you are on a footpath
    for road_types, dist, level in ((("motorway", "trunk", "primary", "motorway_link", "trunk_link"), 50, 0.6),
                                     (("secondary",), 25, 0.45)):
        big = edges[edges["hw"].isin(road_types)]
        if len(big):
            zone = shapely.union_all(list(big.geometry.buffer(dist)))
            near = shapely.intersects(zone, edges.geometry.centroid.to_numpy())
            traffic[near] = np.maximum(traffic[near], level)

    if readings:
        mids = edges.geometry.centroid.to_crs(4326)
        bg = np.array([idw(p.y, p.x, readings) for p in mids])
        bg = np.clip(bg / 150, 0, 1)        # AQI 150 ("unhealthy") -> 1.0
        score = 0.4 * bg + 0.6 * traffic
    else:
        score = traffic
    return np.clip(score, 0, 1)


# ---------------------------------------------------------------------------
# 4. Recent verified weather and air quality (Open-Meteo, free, no key)
# ---------------------------------------------------------------------------
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
AIR_URL = "https://air-quality-api.open-meteo.com/v1/air-quality"


def _hourly(url, params):
    """One Open-Meteo request: 10 s to connect, 30 s for an answer, one retry, then give up."""
    host = url.split("/")[2]
    for attempt in (1, 2):
        print(f"   asking {host}..." + (" (second try)" if attempt == 2 else ""), flush=True)
        try:
            r = requests.get(url, params=params, timeout=(10, 30))
            r.raise_for_status()
            return r.json()["hourly"]
        except Exception as exc:
            if attempt == 2:
                raise
            print(f"   no answer ({type(exc).__name__}), trying once more in 5 seconds...", flush=True)
            time.sleep(5)


def local_today(tz_name):
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo(tz_name)).date()
    except Exception:
        return datetime.now(timezone.utc).date()


def complete_days(hourly, fields):
    """Dates for which every hour in HOURS has a value for every field."""
    by_day = {}
    for i, t in enumerate(hourly["time"]):
        day, hour = t[:10], int(t[11:13])
        if hour in HOURS:
            ok = all(hourly[f][i] is not None for f in fields)
            by_day.setdefault(day, []).append(ok)
    return sorted(d for d, oks in by_day.items() if len(oks) == len(HOURS) and all(oks))


def pick_recent_days(lat, lon, tz_name, n):
    """The n most recent days with verified hourly weather. Returns (days, weather hourly, source text)."""
    today = local_today(tz_name)
    fields = ["temperature_2m", "apparent_temperature"]
    base = {"latitude": round(lat, 4), "longitude": round(lon, 4), "hourly": ",".join(fields), "timezone": tz_name}
    try:  # ERA5 reanalysis: the checked historical record, about 5 days behind
        hourly = _hourly(ARCHIVE_URL, {**base, "start_date": str(today - timedelta(days=n + 14)),
                                       "end_date": str(today - timedelta(days=1))})
        days = complete_days(hourly, fields)[-n:]
        if len(days) == n:
            return days, hourly, "Open-Meteo historical weather (ERA5 reanalysis)"
    except Exception as exc:
        print(f"   historical weather archive failed ({type(exc).__name__}), trying recent analysis...")
    try:  # fallback: the weather model's analysis of the last few days
        hourly = _hourly(FORECAST_URL, {**base, "past_days": n + 1, "forecast_days": 1})
        days = [d for d in complete_days(hourly, fields) if d < str(today)][-n:]
        if days:
            return days, hourly, "Open-Meteo recent weather analysis"
    except Exception as exc:
        print(f"   recent weather failed too ({type(exc).__name__})")
    days = [str(today - timedelta(days=i)) for i in range(n + 5, 5, -1)]
    print("   no weather data available - using placeholder temperatures")
    return days, None, "placeholder values (weather download failed)"


def weather_series(hourly, days):
    if hourly is None:
        n = len(days) * len(HOURS)
        return [30.0] * n, [32.0] * n
    temp = dict(zip(hourly["time"], hourly["temperature_2m"]))
    feel = dict(zip(hourly["time"], hourly["apparent_temperature"]))
    keys = [f"{d}T{h:02d}:00" for d in days for h in HOURS]
    return [round(temp[k], 1) for k in keys], [round(feel[k], 1) for k in keys]


def monthly_weather(lat, lon, tz_name, year):
    days = [f"{year}-{m:02d}-15" for m in range(1, 13)]
    try:
        hourly = _hourly(ARCHIVE_URL, {"latitude": round(lat, 4), "longitude": round(lon, 4),
                                       "hourly": "temperature_2m,apparent_temperature", "timezone": tz_name,
                                       "start_date": days[0], "end_date": days[-1]})
        return days, hourly, f"Open-Meteo historical weather ({year})"
    except Exception as exc:
        print(f"   weather download failed ({type(exc).__name__})")
        return days, None, "placeholder values (weather download failed)"


def air_quality_series(lat, lon, tz_name, days):
    """Hourly city-wide PM2.5, NO2 and US AQI from Copernicus (CAMS) for the chosen days."""
    fields = ["pm2_5", "nitrogen_dioxide", "us_aqi"]
    try:
        hourly = _hourly(AIR_URL, {"latitude": round(lat, 4), "longitude": round(lon, 4), "hourly": ",".join(fields),
                                   "timezone": tz_name, "start_date": min(days), "end_date": max(days)})
    except Exception as exc:
        print(f"   air quality download failed ({type(exc).__name__}) - using the traffic score only")
        return None
    out = {}
    for f in fields:
        lookup = dict(zip(hourly["time"], hourly[f]))
        vals = [lookup.get(f"{d}T{h:02d}:00") for d in days for h in HOURS]
        known = [v for v in vals if v is not None]
        if not known:
            return None
        fill = sum(known) / len(known)
        out[f] = [round(v if v is not None else fill, 1) for v in vals]
    return {"pm25": out["pm2_5"], "no2": out["nitrogen_dioxide"], "aqi": [int(round(v)) for v in out["us_aqi"]]}


# ---------------------------------------------------------------------------
# 5. Downloading from OpenStreetMap
# ---------------------------------------------------------------------------
def first(value):
    return value[0] if isinstance(value, list) else value


# OpenStreetMap data servers ("Overpass API"). If the main one is busy, try the others.
OVERPASS_SERVERS = [
    "https://overpass-api.de/api",
    "https://overpass.kumi.systems/api",
    "https://overpass.private.coffee/api",
    "https://maps.mail.ru/osm/tools/overpass/api",
]


CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")
SERVER_MEMORY = os.path.join(CACHE_DIR, "working_server.txt")


def _load_server_order():
    """Put the server that worked last time first, so we don't wait for busy ones."""
    try:
        with open(SERVER_MEMORY) as f:
            best = f.read().strip()
        if best in OVERPASS_SERVERS:
            OVERPASS_SERVERS.remove(best)
            OVERPASS_SERVERS.insert(0, best)
    except OSError:
        pass


def _remember_server(url):
    if OVERPASS_SERVERS[0] != url:
        OVERPASS_SERVERS.remove(url)
        OVERPASS_SERVERS.insert(0, url)
    try:
        os.makedirs(os.path.dirname(SERVER_MEMORY), exist_ok=True)
        with open(SERVER_MEMORY, "w") as f:
            f.write(url)
    except OSError:
        pass


def with_backup_servers(ox, fn, *args, quick=False, **kwargs):
    """Run an OSMnx download, switching to a backup server if one is busy or refuses.
    The server that works is remembered and tried first next time.
    quick=True is for optional extras: one try per server, 2 minutes each, no long waits."""
    last_error = None
    for attempt in range(1 if quick else 2):
        for url in list(OVERPASS_SERVERS):
            ox.settings.overpass_url = url
            # don't wait 5 minutes for a server that isn't answering: short wait for untested servers
            ox.settings.requests_timeout = 120 if quick else (300 if url == OVERPASS_SERVERS[0] and attempt == 0 else 90)
            try:
                result = fn(*args, **kwargs)
                if url != OVERPASS_SERVERS[0]:
                    print(f"   got it from {url.split('/')[2]} - will use this server first from now on")
                _remember_server(url)
                return result
            except Exception as exc:
                if type(exc).__name__ == "InsufficientResponseError":
                    _remember_server(url)
                    raise  # the server answered fine, there is simply no data of this kind
                last_error = exc
                print(f"   server {url.split('/')[2]} didn't work ({type(exc).__name__}), trying the next one...")
                time.sleep(3)
        if quick:
            break
        print("   all servers busy - waiting 60 seconds and trying again...")
        time.sleep(60)
    raise RuntimeError("Could not download OpenStreetMap data from any server. "
                       "Wait 10 minutes and run the script again.") from last_error


CONTEXT_TAGS = {
    "natural": ["water", "beach", "sand", "scrub", "grassland"],
    "water": True, "waterway": ["riverbank", "dock"],
    "leisure": ["park", "garden", "pitch", "playground"],
    "landuse": ["grass", "recreation_ground", "village_green"],
}
PLACE_TAGS = {
    "amenity": ["restaurant", "cafe", "fast_food", "school", "university", "college", "hospital", "clinic",
                "pharmacy", "bank", "place_of_worship", "library", "theatre", "cinema", "bus_station",
                "marketplace", "police", "post_office", "community_centre", "townhall", "embassy"],
    "shop": ["mall", "supermarket", "department_store"], "tourism": ["attraction", "museum", "hotel", "gallery", "viewpoint"],
    "leisure": ["park", "garden", "sports_centre", "stadium"],
    "railway": ["station", "halt"], "public_transport": ["station"], "historic": ["monument", "memorial", "building"],
}
SKIP_AMENITY = {"parking", "parking_space", "bench", "waste_basket", "bicycle_parking", "vending_machine",
                "toilets", "drinking_water", "parking_entrance", "recycling", "telephone", "post_box",
                "atm", "motorcycle_parking", "shelter", "clock", "fountain"}


def place_kind(row):
    for col in ("railway", "public_transport", "shop", "tourism", "historic", "healthcare",
                "leisure", "office", "amenity"):
        val = row.get(col)
        if isinstance(val, str) and val:
            if col in ("railway", "public_transport"):
                return "station"
            if col == "shop" and val == "yes":
                return "shop"
            if col == "office":
                return "office"
            return val.replace("_", " ")
    return "place"


def feature_name(row):
    for col in ("name:en", "name"):
        v = row.get(col)
        if isinstance(v, str) and v.strip():
            return v.strip()
    return None


def load_osm(bbox):
    import osmnx as ox
    ox.settings.use_cache = True
    ox.settings.cache_folder = CACHE_DIR
    ox.settings.requests_timeout = 300
    _load_server_order()
    ox.settings.http_user_agent = "AirMaps student SDG project (osmnx)"
    if "name:en" not in ox.settings.useful_tags_way:  # English street names for the directions
        ox.settings.useful_tags_way = list(ox.settings.useful_tags_way) + ["name:en"]
    print("1/5 Downloading walkable streets from OpenStreetMap...")
    G = with_backup_servers(ox, ox.graph_from_bbox, bbox=bbox, network_type="walk", simplify=True)
    G = ox.convert.to_undirected(G)
    Gp = ox.project_graph(G)
    nodes_ll, _ = ox.graph_to_gdfs(G)
    _, edges = ox.graph_to_gdfs(Gp)
    edges = edges.reset_index()
    print(f"   {len(nodes_ll)} junctions, {len(edges)} street segments")

    print("2/5 Downloading buildings, trees, water, parks and places...")
    print("   buildings...", flush=True)
    buildings = with_backup_servers(ox, ox.features_from_bbox, bbox=bbox, tags={"building": True}).to_crs(edges.crs)
    buildings = buildings[buildings.geometry.geom_type.isin(["Polygon", "MultiPolygon"])].copy()
    print(f"   {len(buildings)} buildings. Trees...", flush=True)
    try:
        trees = with_backup_servers(ox, ox.features_from_bbox, bbox=bbox, quick=True,
                                    tags={"natural": ["tree", "tree_row"]}).to_crs(edges.crs)
        trees = list(trees.geometry.buffer(TREE_CANOPY_RADIUS_M))
    except Exception:
        trees = []

    print(f"   {len(trees)} trees. Water and parks...", flush=True)
    context = []
    try:
        feats = with_backup_servers(ox, ox.features_from_bbox, bbox=bbox, quick=True, tags=CONTEXT_TAGS)
        feats = feats[feats.geometry.geom_type.isin(["Polygon", "MultiPolygon"])]
        for _, row in feats.iterrows():
            is_water = any(isinstance(row.get(c), str) for c in ("water", "waterway")) or \
                row.get("natural") == "water"
            kind = "water" if is_water else ("sand" if row.get("natural") in ("beach", "sand", "scrub") else "green")
            context.extend(polygon_rings(row.geometry.simplify(0.00003), kind))
    except Exception as exc:
        print(f"   (no water/park layer: {type(exc).__name__})")

    print(f"   {len(context)} water/park areas. Places for search (optional, skipped if the server is too slow)...", flush=True)
    places = []
    try:
        feats = with_backup_servers(ox, ox.features_from_bbox, bbox=bbox, quick=True, tags=PLACE_TAGS)
        for _, row in feats.iterrows():
            if row.get("amenity") in SKIP_AMENITY:
                continue
            name = feature_name(row)
            if name:
                pt = row.geometry.representative_point()
                places.append({"n": name, "k": place_kind(row), "p": [round(pt.y, 5), round(pt.x, 5)]})
    except Exception as exc:
        print(f"   (skipped places for search: {type(exc).__name__}) - street names still work in search")
    return nodes_ll, edges, buildings, trees, context, places


def polygon_rings(geom, kind):
    out = []
    for part in (geom.geoms if isinstance(geom, MultiPolygon) else [geom]):
        if part.is_empty or part.geom_type != "Polygon":
            continue
        rings = [[[round(x, 5), round(y, 5)] for x, y in part.exterior.coords]]
        rings += [[[round(x, 5), round(y, 5)] for x, y in r.coords] for r in part.interiors]
        out.append({"k": kind, "c": rings})
    return out


# ---------------------------------------------------------------------------
# 6. Preparing and writing
# ---------------------------------------------------------------------------
def street_name(row):
    """English street name if mapped, otherwise the local name, otherwise ''."""
    for col in ("name:en", "name"):
        val = first(row.get(col)) if col in row else None
        if isinstance(val, str) and val.strip():
            return val.strip()
    return ""


def prepare(edges, buildings, default_height):
    edges["hw"] = edges["highway"].map(first)
    is_cov = np.zeros(len(edges), dtype=bool)
    for c in ("covered", "tunnel"):
        if c in edges.columns:
            is_cov |= edges[c].map(lambda v: str(first(v)).lower() in ("yes", "arcade", "building_passage")).to_numpy()
    edges["covered"] = is_cov
    edges["nm"] = [street_name(row) for _, row in edges.iterrows()]
    h_tag = buildings["height"] if "height" in buildings.columns else [None] * len(buildings)
    l_tag = buildings["building:levels"] if "building:levels" in buildings.columns else [None] * len(buildings)
    buildings["h"] = [parse_height(h, l, default_height) for h, l in zip(h_tag, l_tag)]
    buildings["real"] = [parse_height(h, l, None) is not None for h, l in zip(h_tag, l_tag)]
    buildings["bname"] = [feature_name(r) for _, r in buildings.iterrows()] if len(buildings) else []
    # one row per polygon part (a building made of several pieces becomes several rows)
    exploded = buildings.explode(index_parts=False).reset_index(drop=True)
    exploded = exploded[exploded.geometry.geom_type == "Polygon"].reset_index(drop=True)
    return exploded, int(buildings["real"].sum())


def export_buildings(buildings):
    """Building outlines (lon/lat) with heights, slightly simplified, for the 3D view."""
    out = []
    ll = buildings.geometry.simplify(0.6).to_crs(4326)
    for geom, h, real in zip(ll, buildings["h"], buildings["real"]):
        if geom.is_empty or geom.geom_type != "Polygon":
            continue
        ring = [[round(x, 5), round(y, 5)] for x, y in geom.exterior.coords]
        out.append({"h": round(float(h), 1), "r": int(bool(real)), "c": ring})
    return out


def collect_places(places, buildings):
    """Named places for search: OSM places plus named buildings, without duplicates."""
    seen, out = set(), []
    pts = buildings.geometry.representative_point().to_crs(4326) if len(buildings) else []
    named_bldgs = [{"n": n, "k": "building", "p": [round(p.y, 5), round(p.x, 5)]}
                   for n, p in zip(buildings["bname"], pts) if isinstance(n, str) and n]
    for p in places + named_bldgs:
        key = p["n"].lower()
        if key not in seen:
            seen.add(key); out.append(p)
    return out[:MAX_PLACES]


def encode_percent(values):
    """0..1 values -> one letter each, in 5% steps ('a' = 0%, 'u' = 100%). Keeps the file small."""
    q = np.clip(np.rint(np.asarray(values) * 20), 0, 20).astype(int)
    return "".join(chr(97 + v) for v in q)


def slugify(text):
    s = "".join(ch if ch.isalnum() else "-" for ch in text.lower())
    while "--" in s:
        s = s.replace("--", "-")
    return s.strip("-") or "area"


def write_output(path, nodes_ll, edges, edges_ll, exposure, side, pollution, meta, buildings=None,
                 context=None, places=None):
    node_index = {nid: i for i, nid in enumerate(nodes_ll.index)}
    out_edges = []
    for i, row in enumerate(edges.itertuples()):
        coords = [[round(y, 5), round(x, 5)] for x, y in edges_ll.geometry.iloc[i].coords]
        sd = "".join(str(int(s)) for s in side[i])
        out_edges.append({
            "u": node_index[row.u], "v": node_index[row.v],
            "len": round(float(row.length), 1),
            "hw": row.hw,
            "nm": row.nm,
            "pol": int(round(pollution[i] * 100)),
            "s": encode_percent(exposure[i]),            # share in sun, per day and hour
            "sd": sd if sd.strip("0") else "",           # shadier pavement: 0 either, 1 left, 2 right
            "g": coords,
        })
    out = {"meta": meta,
           "nodes": [[round(y, 6), round(x, 6)] for x, y in zip(nodes_ll["x"], nodes_ll["y"])],
           "edges": out_edges,
           "buildings": export_buildings(buildings) if buildings is not None else [],
           "context": context or [],
           "places": places or []}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, separators=(",", ":"), ensure_ascii=False)
    print(f"\nDone -> {path} ({os.path.getsize(path) / 1e6:.1f} MB)")


def update_area_index(data_dir, slug, name, filename, about=""):
    """Keep web/data/areas.json listing every area built, so the app can switch between them."""
    index_path = os.path.join(data_dir, "areas.json")
    try:
        with open(index_path, encoding="utf-8") as f:
            areas = json.load(f)
    except (OSError, ValueError):
        areas = []
    areas = [a for a in areas if a.get("slug") != slug] + [{"slug": slug, "name": name, "file": filename, "about": about}]
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump(areas, f, indent=1, ensure_ascii=False)
    print(f"   areas available in the app: {', '.join(a['name'] for a in areas)}")


def build_area(cfg, data_dir, mode):
    bbox = tuple(cfg["bbox"])
    lat, lon = (bbox[1] + bbox[3]) / 2, (bbox[0] + bbox[2]) / 2
    print(f"\n===== {cfg['name']} =====")
    print("0/5 Finding the most recent verified weather...")
    if mode["kind"] == "monthly":
        day_strs, weather_hourly, weather_src = monthly_weather(lat, lon, cfg["tz"], mode["year"])
    elif mode["kind"] == "date":
        day_strs = [mode["date"]]
        weather_hourly, weather_src = None, "placeholder values"
        try:
            weather_hourly = _hourly(ARCHIVE_URL, {"latitude": round(lat, 4), "longitude": round(lon, 4),
                                                   "hourly": "temperature_2m,apparent_temperature", "timezone": cfg["tz"],
                                                   "start_date": mode["date"], "end_date": mode["date"]})
            weather_src = "Open-Meteo historical weather (ERA5 reanalysis)"
        except Exception as exc:
            print(f"   weather download failed ({type(exc).__name__})")
    else:
        day_strs, weather_hourly, weather_src = pick_recent_days(lat, lon, cfg["tz"], mode["n"])
    days = [datetime.strptime(d, "%Y-%m-%d") for d in day_strs]
    print(f"   modelling {day_strs[0]}" + (f" to {day_strs[-1]}" if len(day_strs) > 1 else "") + f" ({weather_src})")
    nodes_ll, edges, buildings, trees, context, raw_places = load_osm(bbox)
    buildings, known = prepare(edges, buildings, cfg["default_height"])
    places = collect_places(raw_places, buildings)
    print(f"   {len(buildings)} building parts ({known} buildings with real height/floors, the rest assumed "
          f"{cfg['default_height']:.0f} m), {len(trees)} trees, {len(context)} water/green areas, "
          f"{len(places)} places for search")

    print(f"3/5 Calculating shade: {len(days)} days x {len(HOURS)} hours...")
    exposure, side, elevations, azimuths = compute_sun_exposure(
        edges, buildings, trees, lat, lon, days, cfg["tz"], cfg.get("utc_offset"))

    print("4/5 Air quality...")
    readings, aq_sources = [], []
    aq = air_quality_series(lat, lon, cfg["tz"], day_strs)
    if aq:
        aq_sources.append("Copernicus CAMS hourly city readings (via Open-Meteo)")
        print(f"   city PM2.5 {min(aq['pm25'])}-{max(aq['pm25'])} µg/m³, US AQI {min(aq['aqi'])}-{max(aq['aqi'])}")
    if os.environ.get("WAQI_TOKEN"):
        try:
            st = waqi_stations(bbox, os.environ["WAQI_TOKEN"])
            readings += st
            aq_sources.append(f"WAQI stations ({len(st)})")
            for s in st[:10]:
                print(f"   {s['name'][:50]:50s} AQI {s['aqi']:.0f}")
        except Exception as exc:
            print(f"   WAQI failed: {exc}")
    if os.environ.get("GOOGLE_AQ_KEY"):
        try:
            g = google_grid(bbox, os.environ["GOOGLE_AQ_KEY"])
            readings += g
            aq_sources.append(f"Google Air Quality ({len(g)} points)")
        except Exception as exc:
            print(f"   Google AQ failed: {exc}")
    aq_sources.append("street-level traffic score (OSM road types)")
    pollution = compute_pollution(edges, readings)
    edges_ll = edges.to_crs(4326)

    print("5/5 Weather...")
    temps, feels = weather_series(weather_hourly, day_strs)

    meta = {
        "version": 2, "name": cfg["name"], "tz": cfg["tz"], "units": cfg.get("units", "metric"),
        "bbox": bbox, "days": [f"{d:%Y-%m-%d}" for d in days], "hours": HOURS,
        "sunElevation": elevations, "sunAzimuth": azimuths, "temp": temps, "feelsLike": feels,
        "sunBoostC": SUN_FEELS_LIKE_BOOST_C, "aq": aq,
        "buildings": int(len(buildings)), "buildingsWithHeight": known,
        "sources": {"streets_buildings": "OpenStreetMap contributors (ODbL)",
                    "air": aq_sources, "weather": weather_src},
        "stations": [{"lat": r["lat"], "lon": r["lon"], "aqi": round(r["aqi"]), "name": r["name"]}
                     for r in readings if r["name"] != "google"],
        "generated": datetime.now(timezone.utc).isoformat(timespec="minutes"),
    }
    slug = slugify(cfg["name"])
    filename = f"{slug}.json"
    write_output(os.path.join(data_dir, filename), nodes_ll, edges, edges_ll, exposure, side,
                 pollution, meta, buildings, context, places)
    update_area_index(data_dir, slug, cfg["name"], filename, cfg.get("about", ""))
    named = int((edges["nm"] != "").sum())
    print(f"   {named} of {len(edges)} street segments have names (used for directions)")


# ---------------------------------------------------------------------------
# 7. Keeping the computer happy
# ---------------------------------------------------------------------------
def folder_size_mb(path):
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total / 1e6


def check_disk(path):
    """Stop before the disk gets so full that Windows becomes unstable."""
    free_gb = shutil.disk_usage(os.path.abspath(path if os.path.exists(path) else ".")).free / 1e9
    if free_gb < 0.5:
        print(f"\nSTOPPED: only {free_gb:.2f} GB free on this drive. Windows needs space to run safely.")
        print("Free up at least 2 GB (empty the Recycle Bin, delete old downloads),")
        print("or run:  python build_data.py --clear-cache   to delete saved map downloads.")
        return False
    if free_gb < 2:
        print(f"   warning: only {free_gb:.1f} GB free on this drive - freeing some space is a good idea")
    return True


def be_polite():
    """Run at lower priority so the computer stays responsive while the script works."""
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x00004000)
        else:
            os.nice(5)
    except Exception:
        pass


def recently_built(data_dir, cfg, hours=12):
    path = os.path.join(data_dir, f"{slugify(cfg['name'])}.json")
    return os.path.exists(path) and (time.time() - os.path.getmtime(path)) < hours * 3600


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--city", default=DEFAULT_CITY, help="ready-made area, or 'all' (see --list)")
    ap.add_argument("--list", action="store_true", help="show the ready-made areas and stop")
    ap.add_argument("--bbox", nargs=4, type=float, metavar=("WEST", "SOUTH", "EAST", "NORTH"),
                    help="your own area instead of a ready-made one")
    ap.add_argument("--name", help="name for your own area")
    ap.add_argument("--tz", default="Asia/Dubai", help="time zone of your own area, e.g. Europe/London")
    ap.add_argument("--default-height", type=float, default=12,
                    help="height (m) to assume for buildings with no height in OpenStreetMap")
    ap.add_argument("--recent-days", type=int, default=DEFAULT_RECENT_DAYS,
                    help="how many of the most recent verified days to model (default 7)")
    ap.add_argument("--monthly", action="store_true", help="model the 15th of every month of last year instead")
    ap.add_argument("--date", help="model one particular past day (YYYY-MM-DD)")
    ap.add_argument("--data-dir", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "web", "data"))
    ap.add_argument("--force", action="store_true", help="rebuild areas even if they were built in the last 12 hours")
    ap.add_argument("--clear-cache", action="store_true", help="delete saved map downloads to free disk space, then stop")
    args = ap.parse_args()

    if args.clear_cache:
        size = folder_size_mb(CACHE_DIR) if os.path.isdir(CACHE_DIR) else 0
        shutil.rmtree(CACHE_DIR, ignore_errors=True)
        print(f"Deleted saved downloads ({size:.0f} MB freed). The next build will download again.")
        return 0

    if args.list:
        for key, c in CITIES.items():
            print(f"  {key:16s} {c['name']:32s} {c['about']}")
        return 0

    if args.date:
        mode = {"kind": "date", "date": args.date}
    elif args.monthly:
        mode = {"kind": "monthly", "year": datetime.now().year - 1}
    else:
        mode = {"kind": "recent", "n": max(1, min(args.recent_days, 14))}

    if args.bbox:
        configs = [{"name": args.name or "My area", "bbox": tuple(args.bbox), "tz": args.tz,
                    "utc_offset": None, "units": "us" if args.tz.startswith("America/") else "metric",
                    "default_height": args.default_height, "about": ""}]
    elif args.city == "all":
        configs = list(CITIES.values())
    elif args.city in CITIES:
        configs = [CITIES[args.city]]
    else:
        print(f"Unknown city '{args.city}'. Choose one of: {', '.join(CITIES)} or all")
        return 1

    be_polite()
    if os.path.isdir(CACHE_DIR):
        print(f"(saved map downloads: {folder_size_mb(CACHE_DIR):.0f} MB in the cache folder)")
    for cfg in configs:
        if not check_disk(args.data_dir):
            return 1
        if len(configs) > 1 and not args.force and recently_built(args.data_dir, cfg):
            print(f"\n===== {cfg['name']} =====\n   already built in the last 12 hours - skipping (use --force to rebuild)")
            continue
        build_area(cfg, args.data_dir, mode)
        gc.collect()
    print("\nNext: cd web && python -m http.server 8000   then open http://localhost:8000")
    return 0


if __name__ == "__main__":
    sys.exit(main())
